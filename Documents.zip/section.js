import { useEffect,useState } from 'react';
import avtart from './logolazy.PNG';
import {  AiFillInstagram, AiOutlineTwitter,AiFillSkype } from "react-icons/ai";
import { FaFacebook,} from "react-icons/fa";

const Section = () => {

    const icons = [
        { id: 1, component: <FaFacebook /> },
        { id: 2, component: <AiFillInstagram /> },
        { id: 3, component: <AiOutlineTwitter /> },
        {  id: 4, component: <AiFillSkype />  }
    ]
    const [textIntroduce,setIntroduce] = useState("")

    const handleText = () =>{
        setTimeout(()=>{
                setIntroduce("Lazy.vn")
        },0)
        setTimeout(()=>{
            setIntroduce("Lazy IPA")
        },3000)
        setTimeout(()=>{
            setIntroduce("Web Developer")
        },6000)
    }
    useEffect(()=>{
        if(textIntroduce !== "Mai Thanh Tùng"){
            handleText()
        }
        const interval = setInterval(()=>{
        handleText()
        },9000)
        return () => clearInterval(interval)
    },[])
    console.log("run");
    return (
        <>
            <section className='section'>
                <div className="introduce">
                    <div className='hello'>Xin Chào</div>
                    <div className='name'>MTT</div>
                    {
                       textIntroduce &&  <div className='introduce-text'>I'm  <span className='animation-text'>{textIntroduce}</span></div>
                    }
                    <p className='describe'>
                        Chào Mừng Bạn Đến Với Lazy.vn 
                    </p>

                    <div className='iconWrap'>
                        {
                            icons?.map((value, index) => {
                                return <div className='icon' key={index}>{value.component}</div>
                            })
                        }
                    </div>

                    <button className='btn-downloadCv'>
                       Lazy IPA
                    </button>
                </div>

                <div className="avatarWrap">
                    <div className='moon'>
                        <div className="avtart">
                            <img src={avtart} />
                        </div>
                        <div className='orbit'>
                            <p>✈️</p>
                            {/* <div className='luxurious'>⭐️</div> */}
                            <div className='rob'>☄️</div>
                        </div>
                    </div>
                </div>
            </section>
        </ >
    );
}

export default Section;