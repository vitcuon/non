import './style.css';
import Header from './component/header/header';
import Section from './component/section/section';
function App() {
    return (
        <div className="App" >
            <Header />
            <Section />
        </div >
    );
}

export default App;
