import { useLocation, useNavigate } from 'react-router-dom';

const Header = () => {
    const location = useLocation();
    const navigate = useNavigate();

    const menu = ["Trang Chủ", "", "", "", ""]
    return (
        <>
            <header className='header'>
                <div className='logo'>Hello !</div>
                <div className='menu' >
                    {menu.map(value => {
                        const active = `/${value}` === location?.pathname
                        return (
                            <div
                                key={value}
                                onClick={() => navigate(value)}
                                className={`${active && "menu-active"} menu-text`}
                            >
                                {value}
                            </div>
                        )

                    })}
                </div>
            </header>
        </ >
    );
}

export default Header;